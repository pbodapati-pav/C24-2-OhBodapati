package clueGame;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.List;

/**
 * A panel that displays the known cards (in hand and seen), grouped by type: People, Rooms, Weapons.
 */
public class KnownCardsPanel extends JPanel {
    private JPanel peoplePanel, roomsPanel, weaponsPanel;

    public KnownCardsPanel() {
        setLayout(new GridLayout(3, 1)); // 3 sections: People, Rooms, Weapons

        // Initialize each group panel
        peoplePanel = createCardGroupPanel("People");
        roomsPanel = createCardGroupPanel("Rooms");
        weaponsPanel = createCardGroupPanel("Weapons");

        // Add them to the main panel
        add(peoplePanel);
        add(roomsPanel);
        add(weaponsPanel);
    }

    /**
     * Creates a section with a title, and two sub-sections: "In Hand" and "Seen"
     */
    private JPanel createCardGroupPanel(String title) {
        JPanel groupPanel = new JPanel(new GridLayout(2, 1)); // Top: In Hand, Bottom: Seen
        groupPanel.setBorder(new TitledBorder(title));

        // Top: In Hand
        JPanel inHandPanel = new JPanel();
        inHandPanel.setLayout(new BoxLayout(inHandPanel, BoxLayout.Y_AXIS));
        inHandPanel.setBorder(BorderFactory.createTitledBorder("In Hand"));
        groupPanel.add(inHandPanel);

        // Bottom: Seen
        JPanel seenPanel = new JPanel();
        seenPanel.setLayout(new BoxLayout(seenPanel, BoxLayout.Y_AXIS));
        seenPanel.setBorder(BorderFactory.createTitledBorder("Seen"));
        groupPanel.add(seenPanel);

        return groupPanel;
    }

    /**
     * Updates one group panel with both in-hand and seen cards.
     */
    private void populateCardGroup(JPanel panel, List<String> inHand, List<String> seen, Color seenColor) {
        // Get the top and bottom sections of the group panel
        JPanel inHandPanel = (JPanel) panel.getComponent(0);
        JPanel seenPanel = (JPanel) panel.getComponent(1);

        // Clear and add in-hand cards
        inHandPanel.removeAll();
        for (String card : inHand) {
            JTextField field = new JTextField(" " + card);
            field.setEditable(false);
            field.setFont(new Font("SansSerif", Font.PLAIN, 14));
            field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
            field.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
            inHandPanel.add(field);
        }

        // Clear and add seen cards with background color
        seenPanel.removeAll();
        for (String card : seen) {
            JTextField field = new JTextField(" " + card);
            field.setEditable(false);
            field.setFont(new Font("SansSerif", Font.PLAIN, 14));
            field.setBackground(seenColor);
            field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25));
            field.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
            seenPanel.add(field);
        }

        // Refresh display
        panel.revalidate();
        panel.repaint();
    }

    /**
     * Updates all card groups using player data.
     */
    public void setKnownCards(List<String> peopleInHand, List<String> peopleSeen,
                              List<String> roomInHand, List<String> roomSeen,
                              List<String> weaponInHand, List<String> weaponSeen) {
        populateCardGroup(peoplePanel, peopleInHand, peopleSeen, Color.PINK);
        populateCardGroup(roomsPanel, roomInHand, roomSeen, Color.CYAN);
        populateCardGroup(weaponsPanel, weaponInHand, weaponSeen, Color.MAGENTA);
    }
    
    /**
     * Populates the KnownCardsPanel using the given player's hand and seen cards.
     * Cards are categorized into People, Rooms, and Weapons, and then passed to the panel.
     *
     */
    public void setPlayer(Player player) {
    	// Lists to hold categorized card names
        List<String> peopleInHand = new java.util.ArrayList<>();
        List<String> peopleSeen = new java.util.ArrayList<>();
        List<String> roomsInHand = new java.util.ArrayList<>();
        List<String> roomsSeen = new java.util.ArrayList<>();
        List<String> weaponsInHand = new java.util.ArrayList<>();
        List<String> weaponsSeen = new java.util.ArrayList<>();
        
        // Separate the player's hand into categories
        for (Card card : player.getHand()) {
            switch (card.getType()) {
                case PERSON -> peopleInHand.add(card.getCardName());
                case ROOM -> roomsInHand.add(card.getCardName());
                case WEAPON -> weaponsInHand.add(card.getCardName());
            }
        }	
        
        // Separate the player's seen cards into categories
        for (Card card : player.getSeen()) {
            switch (card.getType()) {
                case PERSON -> peopleSeen.add(card.getCardName());
                case ROOM -> roomsSeen.add(card.getCardName());
                case WEAPON -> weaponsSeen.add(card.getCardName());
            }
        }
        
        // Send all sorted lists to the panel for display
        setKnownCards(peopleInHand, peopleSeen, roomsInHand, roomsSeen, weaponsInHand, weaponsSeen);
    }

    /**
     * For testing: displays the panel in a standalone window.
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("Known Cards");
        KnownCardsPanel panel = new KnownCardsPanel();

        panel.setKnownCards(
            List.of("Miss Scarlet", "Colonel Mustard"),
            List.of("Mrs. White", "Mr. Green"),
            List.of("Kitchen"),
            List.of("Ballroom", "Library"),
            List.of("Lead Pipe"),
            List.of("Rope", "Candlestick")
        );

        frame.setContentPane(panel);
        frame.setSize(300, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
