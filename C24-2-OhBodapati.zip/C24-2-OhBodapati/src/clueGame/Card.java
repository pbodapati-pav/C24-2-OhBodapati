package clueGame;

public class Card {
	private String cardName;
	private CardType type;

	public Card(String cardName, CardType type) {
		this.cardName = cardName;
		this.type = type;
	}
	
	// Returns the name of the card.
	public String getCardName() {
		return cardName;
	}
	
	// Returns the type of the card (e.g., PERSON, ROOM, WEAPON).
	public CardType getType() {
		return type;
	}
	
	// Checks whether two cards are equal by comparing their name and type.
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Card)) {
			return false;
		}
		Card other = (Card) obj;
		return this.cardName.equals(other.cardName) && this.type == other.type;
	}
	
	
	@Override
	public int hashCode() {
		// Generates a hash code based on the card's name and type.
	    // Ensures proper behavior in hash-based collections (e.g., HashSet, HashMap),
	    // especially when used alongside the equals() method.
	    return cardName.hashCode() + type.hashCode();
	}
	
	// Returns a string representation of the card in the format "name (type)".
	@Override
	public String toString() {
		return cardName + " (" + type + ")";
	}
	
}
