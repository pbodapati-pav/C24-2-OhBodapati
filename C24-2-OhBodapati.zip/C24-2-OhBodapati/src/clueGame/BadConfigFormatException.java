package clueGame;


//Exception thrown when configuration files are incorrectly formatted.
public class BadConfigFormatException extends Exception {
    public BadConfigFormatException(String message) {
        super(message);
    }
}