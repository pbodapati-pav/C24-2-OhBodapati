package clueGame;

import java.util.Objects;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;

public class BoardCell {
    private int row;
    private int col;
    private char initial;
    private DoorDirection doorDirection;
    private boolean isRoomCenter;
    private boolean isLabel;
    private char secretPassage = ' '; // Default to empty
    private boolean occupied = false;

    public BoardCell(int row, int col, char initial) {
        this.row = row;
        this.col = col;
        this.initial = initial;
        this.doorDirection = DoorDirection.NONE;
    }

    //Checks if the cell is a doorway.
    public boolean isDoorway() {
        return doorDirection != DoorDirection.NONE;
    }

    //Returns the row index of the cell.
    public int getRow() {
        return row;
    }

    //Returns the column index of the cell.
    public int getCol() {
        return col;
    }

    //Returns the initial character representing the room.
    public char getInitial() {
        return initial;
    }

    /**
     * Sets the door direction for the cell.
     */
    public void setDoorDirection(DoorDirection direction) {
        this.doorDirection = direction;
    }

    //Gets the door direction for the cell.
    public DoorDirection getDoorDirection() {
        return doorDirection;
    }

    //Checks if the cell is a room label.
    public boolean isLabel() {
        return isLabel;
    }

    //Checks if the cell is the center of a room.
    public boolean isRoomCenter() {
        return isRoomCenter;
    }

    //Returns the secret passage destination (or ' ' if none exists)
    public char getSecretPassage() {
    	return secretPassage;
    }
    //Marks this cell as the label of a room
    public void setLabel(boolean isLabel) {
        this.isLabel = isLabel;
    }
    // Marks this cell as the center of a room
    public void setRoomCenter(boolean isRoomCenter) {
        this.isRoomCenter = isRoomCenter;
    }
    //Sets the destination room for secret passages
    public void setSecretPassage(char passage) {
        this.secretPassage = passage;
    }
    
    //Returns false on walkway for  default:
	public boolean isWalkway() {
		return initial == 'W';
	}
	
	//Marks the cell as occupied (prevents movement onto this cell)
	public void setOccupied(boolean occupied) {
	    this.occupied = occupied;
	}
	
	//Returns whether the cell is occupied
	public boolean isOccupied() {
	    return occupied;
	}
	
	/**
	 * Overrides equals to compare BoardCell objects by row and column.
	 * This is useful for adjacency and target calculations.
	 */
	@Override
	public boolean equals(Object obj) {
	    if (this == obj) return true;
	    if (obj == null || getClass() != obj.getClass()) return false;
	    BoardCell other = (BoardCell) obj;
	    return row == other.row && col == other.col;
	}
	
	/**
	 * Overrides hashCode to be consistent with equals().
	 * Allows BoardCell to be used in hash-based collections (e.g., HashSet).
	 */
	@Override
	public int hashCode() {
	    return Objects.hash(row, col);
	}
	
	
	/**
	 * Draws the individual cell on the board based on its type.
	 * Handles walkways, rooms, unused areas, doorways, and labels.
	 *
	 */
	public void draw(Graphics g, int cellWidth, int cellHeight, String roomName) {
	    int x = col * cellWidth;
	    int y = row * cellHeight;

	    // Walkway
	    if (initial == 'W') {
	        g.setColor(Color.YELLOW);
	        g.fillRect(x, y, cellWidth, cellHeight);
	        g.setColor(Color.BLACK);
	        g.drawRect(x, y, cellWidth, cellHeight);
	    }
	    // Unused (X) room label blocks
	    else if (roomName.equals("Unused")) {
	        g.setColor(Color.BLACK);
	        g.fillRect(x, y, cellWidth, cellHeight);
	    }
	    // Regular room cell
	    else {
	        g.setColor(Color.LIGHT_GRAY);
	        g.fillRect(x, y, cellWidth, cellHeight);
	    }

	    // Room label drawing (multi-line if needed)
	    if (isLabel && !roomName.equals("Unused")) {
	    	g.setColor(Color.BLUE);

	        // Use slightly smaller font
	        Font font = new Font("SansSerif", Font.BOLD, cellHeight / 3);
	        g.setFont(font);
	        FontMetrics metrics = g.getFontMetrics();

	        if (roomName.contains(" ")) {
	            String[] parts = roomName.split(" ", 2);
	            int width1 = metrics.stringWidth(parts[0]);
	            int width2 = metrics.stringWidth(parts[1]);

	            g.drawString(parts[0], x + (cellWidth - width1) / 2, y + cellHeight / 2 - 2);
	            g.drawString(parts[1], x + (cellWidth - width2) / 2, y + cellHeight - 4);
	        } else {
	            int width = metrics.stringWidth(roomName);
	            g.drawString(roomName, x + (cellWidth - width) / 2, y + (2 * cellHeight / 3));
	        }
	    }

	    // Doorway rendering
	    if (isDoorway()) {
	        g.setColor(Color.BLUE);
	        int d = 5;  // Thickness of the doorway indicator
	        switch (doorDirection) {
	            case UP -> g.fillRect(x, y, cellWidth, d);
	            case DOWN -> g.fillRect(x, y + cellHeight - d, cellWidth, d);
	            case LEFT -> g.fillRect(x, y, d, cellHeight);
	            case RIGHT -> g.fillRect(x + cellWidth - d, y, d, cellHeight);
	            case NONE -> {}
	        }
	    }
	}

}
