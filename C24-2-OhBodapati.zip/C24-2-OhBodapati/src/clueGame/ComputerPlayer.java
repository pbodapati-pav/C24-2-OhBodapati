package clueGame;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Represents a computer-controlled player in the game.
 * Inherits from the abstract Player class.
 */
public class ComputerPlayer extends Player {
	private Set<Card> seen = new HashSet<>();
	private String lastRoomVisited = "";
	
	public ComputerPlayer(String name, Color color, int row, int column) {
        super(name, color, row, column);
    }
	
	//Returns the set of cards the computer player has already seen.
	public Set<Card> getSeen() {
	    return seen;
	}
	
	//Stores the name of the last room the player visited. 
	//Used by the AI in selectTargets() to avoid re-entering the same room twice in a row, which makes its movement more intelligent.
	public void setLastRoomVisited(String room) {
	    this.lastRoomVisited = room;
	}
	
	
	//Generates a new suggestion (a combination of person, weapon, and room) based on the player's current room and the cards it has not yet seen.
	public Solution createSuggestion() {
	    // Get current room name from the board
	    BoardCell location = Board.getInstance().getCell(getRow(), getColumn());
	    String roomName = Board.getInstance().getRoom(location).getName();
	    Card roomCard = new Card(roomName, CardType.ROOM);

	    // Filter unseen people and weapons
	    ArrayList<Card> unseenPeople = new ArrayList<>();
	    ArrayList<Card> unseenWeapons = new ArrayList<>();

	    for (Card c : Board.getInstance().getDeck()) {
	        if (!seen.contains(c)) {
	            if (c.getType() == CardType.PERSON) unseenPeople.add(c);
	            if (c.getType() == CardType.WEAPON) unseenWeapons.add(c);
	        }
	    }

	    if (unseenPeople.isEmpty() || unseenWeapons.isEmpty()) {
	        throw new IllegalStateException("Cannot create suggestion — no unseen people or weapons remaining.");
	    }

	    Random rand = new Random();
	    Card person = unseenPeople.get(rand.nextInt(unseenPeople.size()));
	    Card weapon = unseenWeapons.get(rand.nextInt(unseenWeapons.size()));

	    return new Solution(person, roomCard, weapon);
	}


	//Chooses the next cell (target) the computer player will move to, based on available movement options.
	public BoardCell selectTargets(Set<BoardCell> targets) {
	    // Prioritize unvisited rooms
	    for (BoardCell cell : targets) {
	        if (cell.isRoomCenter() && !Board.getInstance().getRoom(cell).getName().equals(lastRoomVisited)) {
	            lastRoomVisited = Board.getInstance().getRoom(cell).getName();
	            return cell;
	        }
	    }

	    // Otherwise, pick randomly
	    int index = new Random().nextInt(targets.size());
	    return new ArrayList<>(targets).get(index);
	}


}
