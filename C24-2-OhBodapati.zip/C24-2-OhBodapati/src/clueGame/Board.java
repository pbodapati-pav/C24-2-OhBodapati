package clueGame;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.awt.Color;
import java.util.Collections;

public class Board extends JPanel{
    
    private int numRows;
    private int numColumns;
    private static Board theInstance = new Board(); // Singleton instance
    private String layoutConfigFile;
    private String setupConfigFile;
    private Map<Character, Room> roomMap;
    private BoardCell[][] grid;
    private Set<BoardCell> targets;
    private ArrayList<Player> players = new ArrayList<>();
    private ArrayList<Card> deck = new ArrayList<>();
    private Solution theAnswer;
    
    
    //Initialize and create Room Map
    private Board() {
        super();
        roomMap = new HashMap<>();
    }
    
    /**
     * Draws the entire game board by delegating the drawing of each cell to BoardCell.draw().
     * It calculates each cell's size based on the current panel dimensions.
     *
     */
    private void drawBoard(Graphics g) {
    	if (grid == null) return;

        int cellWidth = getWidth() / numColumns;
        int cellHeight = getHeight() / numRows;

        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numColumns; col++) {
                BoardCell cell = grid[row][col];
                String roomName = "";

                Room room = roomMap.get(cell.getInitial());
                if (room != null) {
                    roomName = room.getName();
                }

                cell.draw(g, cellWidth, cellHeight, roomName);
            }
        }
    }
    
    
    /**
     * Draws all player tokens on the board.
     * Each player is drawn based on their row/column location and size of each board cell.
     *	
     */
    private void drawPlayers(Graphics g) {
        int cellWidth = getWidth() / numColumns;
        int cellHeight = getHeight() / numRows;

        for (Player p : players) {
            p.draw(g, cellWidth, cellHeight);// Delegate drawing to each player
        }
    }
    
    // Checks if the given row and column are within the bounds of the board grid.
    private boolean isInBounds(int row, int col) {
        return row >= 0 && row < numRows && col >= 0 && col < numColumns;
    }
    
    //Removes all cards from every player’s hand.
    public void clearPlayerHands() {
        for (Player player : players) {
            player.getHand().clear();
        }
    }
    
    // Converts a string color name to a corresponding Color object. 
    // Returns gray if the color is not recognized.
    private Color convertColor(String colorName) {
    	colorName = colorName.toLowerCase();
    	switch (colorName) {
    		case "red":
    			return Color.RED;
    		case "blue":
                return Color.BLUE;
            case "green":
                return Color.GREEN;
            case "yellow":
                return Color.YELLOW;
            case "white":
                return Color.WHITE;
            case "purple":
                return new Color(128, 0, 128);
            default:
                return Color.GRAY;
    	}
    }
    
    // Deals cards by randomly selecting one person, weapon, and room for the solution,
    // then distributing the remaining cards evenly among players.
    private void dealCards() {
    	
    	for (Player player : players) {
            player.getHand().clear();
        }
        // Separate the deck into three categories
        ArrayList<Card> peopleCards = new ArrayList<>();
        ArrayList<Card> weaponCards = new ArrayList<>();
        ArrayList<Card> roomCards = new ArrayList<>();
        
        for (Card card : deck) {
            switch (card.getType()) {
                case PERSON:
                    peopleCards.add(card);
                    break;
                case WEAPON:
                    weaponCards.add(card);
                    break;
                case ROOM:
                    roomCards.add(card);
                    break;
            }
        }
        
        //Create 3 different cards: Person, Weapon, Room
        Card person;
        Card weapon;
        Card room;

        if (theAnswer == null) {
            person = peopleCards.remove((int) (Math.random() * peopleCards.size()));
            weapon = weaponCards.remove((int) (Math.random() * weaponCards.size()));
            room = roomCards.remove((int) (Math.random() * roomCards.size()));
            theAnswer = new Solution(person, room, weapon);
        } else {
            person = theAnswer.getPerson();
            weapon = theAnswer.getWeapon();
            room = theAnswer.getRoom();

            peopleCards.remove(person);
            weaponCards.remove(weapon);
            roomCards.remove(room);
        }

        // Combine remaining cards and shuffle
        ArrayList<Card> remainingCards = new ArrayList<>();
        remainingCards.addAll(peopleCards);
        remainingCards.addAll(weaponCards);
        remainingCards.addAll(roomCards);
        Collections.shuffle(remainingCards);

        // Deal cards evenly to players
        int index = 0;
        for (Card card : remainingCards) {
            Player player = players.get(index % players.size());
            player.updateHand(card);
            index++;
        }
    }


    
    
    // Considers walkways and valid directional doorways.
    //  Helper method to add valid adjacent cells
    private void addIfValid(Set<BoardCell> adjList, int row, int col, BoardCell origin) {
    	if (!isInBounds(row, col)) return;

        BoardCell neighbor = grid[row][col];

        if (neighbor.isWalkway()) {
            adjList.add(neighbor);
        } else if (neighbor.isDoorway()) {
            DoorDirection dir = neighbor.getDoorDirection();
            //Different switch statements for various directions
            switch (dir) {
                case UP:
                    if (row + 1 == origin.getRow() && col == origin.getCol()) {
                        adjList.add(neighbor);
                    }
                    break;
                case DOWN:
                    if (row - 1 == origin.getRow() && col == origin.getCol()) {
                        adjList.add(neighbor);
                    }
                    break;
                case LEFT:
                    if (col + 1 == origin.getCol() && row == origin.getRow()) {
                        adjList.add(neighbor);
                    }
                    break;
                case RIGHT:
                    if (col - 1 == origin.getCol() && row == origin.getRow()) {
                        adjList.add(neighbor);
                    }
                    break;
                default:
                    break;
            }
        }
    }
    
    // Avoids revisiting already visited cells.
    //  Recursive method to find valid movement targets
    private void findTargets(BoardCell cell, int steps, Set<BoardCell> visited) {
    	visited.add(cell);

        for (BoardCell adj : getAdjList(cell.getRow(), cell.getCol())) {
            if (visited.contains(adj)) continue;

            // If it's occupied
            if (adj.isOccupied()) {
                if (adj.isRoomCenter()) {
                    targets.add(adj); // Can still enter an occupied room
                }
                continue;
            }

            Set<BoardCell> nextVisited = new HashSet<>(visited);
            if (steps == 1 || adj.isRoomCenter()) {
                targets.add(adj);
            } else {
                findTargets(adj, steps - 1, nextVisited);
            }
        }
    }
    


    // Returns the single instance of Board (Singleton pattern).
    public static Board getInstance() {
        return theInstance;
    }

    //Sets the configuration files for layout and setup.
    public void setConfigFiles(String layoutFile, String setupFile) {
        this.layoutConfigFile = layoutFile;
        this.setupConfigFile = setupFile;
    }

    //Initializes the board by reading the configuration files.
    public void initialize() {
    	try {
            loadSetupConfig();
            loadLayoutConfig();
            

            if (numRows <= 0 || numColumns <= 0) {
                throw new RuntimeException("ERROR: Invalid board size (Rows: " + numRows + ", Columns: " + numColumns + ")");
            }

            //System.out.println("Board initialized: " + numRows + " x " + numColumns);
            for (int row = 0; row < numRows; row++) {
                for (int col = 0; col < numColumns; col++) {
                    if (grid[row][col] == null) {
                        throw new RuntimeException(" ERROR: Cell [" + row + "][" + col + "] is null after `loadLayoutConfig()`!");
                    }
                }
            }
            
            
         
            
        } catch (BadConfigFormatException e) {
            System.err.println("Error loading board: " + e.getMessage());
        }
    }

    //Reads the room setup configuration from the setup file. throw BadConfigFormatException if the file format is incorrect.
    public void loadSetupConfig() throws BadConfigFormatException {
    	try {
            InputStream input = getClass().getClassLoader().getResourceAsStream("tests/data/" + setupConfigFile);
            if (input == null) {
                throw new FileNotFoundException("Setup file not found: " + setupConfigFile);
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            String line;

            //System.out.println("Reading " + setupConfigFile);
            
            while ((line = reader.readLine()) != null) {
            	 //System.out.println("Read line: " + line); 

                 if (line.startsWith("//") || line.trim().isEmpty()) continue; 

                 String[] parts = line.split(",");
                 
                 //System.out.println("LINE: " + line);
                 //System.out.println("parts.length = " + parts.length);
                 //System.out.println("parts[0] = \"" + parts[0].trim() + "\"");
                 if (parts.length > 1) {
                     //System.out.println("parts[1] = \"" + parts[1].trim() + "\"");
                 }

                 // WEAPON line: name,WEAPON
                 if (parts.length == 2 && parts[1].trim().equals("WEAPON")) {
                	    String name = parts[0].trim();
                	    Card weaponCard = new Card(name, CardType.WEAPON);
                	    if (!deck.contains(weaponCard)) {
                	        deck.add(weaponCard);
                	    }
                	} else if (parts.length == 5 && parts[1].trim().equals("PERSON")) {
                     String name = parts[0].trim();
                     Color color = convertColor(parts[2].trim());
                     int row = Integer.parseInt(parts[3].trim());
                     int col = Integer.parseInt(parts[4].trim());

                     Player player;
                     if (players.isEmpty()) {
                         player = new HumanPlayer(name, color, row, col);
                     } else {
                         player = new ComputerPlayer(name, color, row, col);
                     }
                     
                     if (players.stream().noneMatch(p -> p.getName().equals(name))) {
                    	    players.add(player);
                    	}
                     Card personCard = new Card(name, CardType.PERSON);
                     if (!deck.contains(personCard)) {
                    	   deck.add(personCard);
                     }


                 // ROOM or SPACE line: Room/Space,name,initial
                 } else if (parts.length == 3 && (parts[0].trim().equals("Room") || parts[0].trim().equals("Space"))) {
                     String type = parts[0].trim();
                     String name = parts[1].trim();
                     char initial = parts[2].trim().charAt(0);
                     roomMap.put(initial, new Room(name));
                     
                     
                     if (type.equals("Room") && !name.equals("Closet")) {
                    	 Card roomCard = new Card(name, CardType.ROOM);
                    	 if (!deck.contains(roomCard)) {
                    	     deck.add(roomCard);
                    	 }
                     }

                 } else {
                     throw new BadConfigFormatException("Unrecognized setup line: " + line);
                 }
                 
            }
            
            reader.close();
            //System.out.println("Deck before dealing has " + deck.size() + " cards");
            long personCount = deck.stream().filter(c -> c.getType() == CardType.PERSON).count();
            long weaponCount = deck.stream().filter(c -> c.getType() == CardType.WEAPON).count();
            //System.out.println("PERSON cards in deck: " + personCount);
            //System.out.println("WEAPON cards in deck: " + weaponCount);

            if (personCount >= 1 && weaponCount >= 1) {
                dealCards();
            }
        } catch (IOException e) {
            throw new BadConfigFormatException("Error reading setup file: " + e.getMessage());
        }
    }

    
    //Reads the board layout configuration from the layout file. throws BadConfigFormatException if the file format is incorrect.
    public void loadLayoutConfig() throws BadConfigFormatException {
    	try {
            //System.out.println("Starting loadLayoutConfig()...");

            InputStream input = getClass().getClassLoader().getResourceAsStream("tests/data/" + layoutConfigFile);
            if (input == null) {
                throw new FileNotFoundException("Layout file not found: " + layoutConfigFile);
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            String line;

            
            int rowCount = 0;
            int columnCount = 0;
            while ((line = reader.readLine()) != null) {
                String[] cells = line.split(",");
                if (rowCount == 0) {
                    columnCount = cells.length;
                } else if (cells.length != columnCount) {
                    throw new BadConfigFormatException("Row " + rowCount + " has incorrect column count!");
                }
                rowCount++;
            }
            numRows = rowCount;
            numColumns = columnCount;
            reader.close();
            //System.out.println("Board dimensions set in loadLayoutConfig(): Rows = " + numRows + ", Columns = " + numColumns);
            grid = new BoardCell[numRows][numColumns]; 
            
            input = getClass().getClassLoader().getResourceAsStream("tests/data/" + layoutConfigFile);
            reader = new BufferedReader(new InputStreamReader(input));
           

            int row = 0;
            while ((line = reader.readLine()) != null) {
                String[] cells = line.split(",");
                for (int col = 0; col < numColumns; col++) {
                	if (col >= cells.length) {
                		throw new BadConfigFormatException("ERROR: Row " + row + " has fewer columns than expected.");
                    }
                    
                    if (cells[col].isEmpty() || cells[col].charAt(0) == ' ') {
                        throw new BadConfigFormatException("Empty or invalid cell at (" + row + "," + col + ")");
                    }
                    
                    char initial = cells[col].charAt(0);
                    
                    if (!roomMap.containsKey(initial)) {
                    	throw new BadConfigFormatException("ERROR: Invalid room initial '" + initial + "' found in layout file at [" + row + "][" + col + "].");
                    }
                    
                    BoardCell cell = new BoardCell(row, col, initial);
                    if (row == 8 && col == 7) {
                        System.out.println("LAYOUT CSV DEBUG @ (8,7): " + cells[col]);
                    }
                    
                    if (cells[col].length() > 1) {
                        char secondChar = cells[col].charAt(1);
                        
                        // Set secret passage only if it's an uppercase letter AND exists in roomMap
                        if (Character.isUpperCase(secondChar)) {
                            if (roomMap.containsKey(secondChar)) {
                                cell.setSecretPassage(secondChar);
                            } else {
                                System.out.println("IGNORED: invalid secret passage to '" + secondChar + "' at (" + row + "," + col + ")");
                            }
                        }
                    	
                        //Switch cases for different symbols for each room.
                        switch (secondChar) {
                            case '>': cell.setDoorDirection(DoorDirection.RIGHT); break;
                            case '<': cell.setDoorDirection(DoorDirection.LEFT); break;
                            case '^': cell.setDoorDirection(DoorDirection.UP); break;
                            case 'v': cell.setDoorDirection(DoorDirection.DOWN); break;
                            case '*': 
                            	Room room = roomMap.get(initial);
                                if (room != null) {
                                    room.setCenterCell(cell);  
                                    cell.setRoomCenter(true);  
                                }
                               
                                break;
                            case '#': 
                            	if (roomMap.containsKey(initial)) {
                                    roomMap.get(initial).setLabelCell(cell);
                                    cell.setLabel(true);
                                }
                            	break;
                        }
                    }

                    grid[row][col] = cell;
                }
                row++;
            }
            // Second pass: assign valid secret passages to center cells
            for (int r = 0; r < numRows; r++) {
                for (int c = 0; c < numColumns; c++) {
                    BoardCell cell = grid[r][c];
                    char passage = cell.getSecretPassage();
                    if (passage != '\0' && roomMap.containsKey(passage)) {
                        Room room = roomMap.get(cell.getInitial());
                        if (room != null && room.getCenterCell() != null) {
                            room.getCenterCell().setSecretPassage(passage);
                        }
                    } 
                }
            }

            reader.close();
            //System.out.println("Finished loadLayoutConfig().");
        } catch (IOException e) {
            throw new BadConfigFormatException("Error reading layout file: " + e.getMessage());
        }
    }
    
    public Set<BoardCell> getAdjList(int row, int col) {
    	//  Ensure the cell is within board boundaries
        if (row < 0 || row >= numRows || col < 0 || col >= numColumns) {
            throw new IllegalArgumentException("Invalid board coordinates: [" + row + "][" + col + "]");
        }

        Set<BoardCell> adjList = new HashSet<>();
        BoardCell cell = grid[row][col];
        
        // Add this:
        if (row == 8 && col == 7) {
            System.out.println("DEBUG: Cell at (8,7) — isWalkway=" + cell.isWalkway() + ", isDoorway=" + cell.isDoorway() + ", isRoomCenter=" + cell.isRoomCenter());
        }
        
        if (cell == null) {
            System.err.println("ERROR: grid[" + row + "][" + col + "] is null!");
            
        }
        
        //System.out.println("Getting adjacents for (" + row + "," + col + "), isRoomCenter = " + cell.isRoomCenter());

        
        //Room Center
        if (cell.isRoomCenter()) {
        	//Add all doorways that connect to this room
        	for (int r = 0; r < numRows; r++) {
        		for (int c = 0; c < numColumns; c++) {
        			BoardCell potentialDoor = grid[r][c];
        			if (potentialDoor.isDoorway()) {
        				Room doorRoom = getRoom(potentialDoor);
        				if (doorRoom != null && doorRoom.getCenterCell() == cell) {
        					//System.out.println("Found door connected to (" + row + "," + col + ") at (" + r + "," + c + ")");
        					adjList.add(potentialDoor);
        				}
        			}
        		}
        	}
        }
        
        if (cell.getSecretPassage() != '\0') {
        	//System.out.println("Checking secret passage to: '" + cell.getSecretPassage() + "' from (" + row + "," + col + ")");
   	     	Room targetRoom = getRoom(cell.getSecretPassage());
   	     	if (targetRoom != null && targetRoom.getCenterCell() != null) {
   	     		adjList.add(targetRoom.getCenterCell());
   	     	}
   	     }
        //Doorway
        if (cell.isDoorway()) {
            int destRow = row, destCol = col;
            switch (cell.getDoorDirection()) {
                case UP: destRow--; break;
                case DOWN: destRow++; break;
                case LEFT: destCol--; break;
                case RIGHT: destCol++; break;
                default: break;
            }
            if (isInBounds(destRow, destCol)) {
                BoardCell destination = grid[destRow][destCol];
                Room room = getRoom(destination);
                if (room != null && room.getCenterCell() != null) {
                    adjList.add(room.getCenterCell());
                }
            }
        }
	        
    
        //  Check movement in four possible directions
        //Walkway
        if (cell.isWalkway()) {
            addIfValid(adjList, row - 1, col, cell);
            addIfValid(adjList, row + 1, col, cell);
            addIfValid(adjList, row, col - 1, cell);
            addIfValid(adjList, row, col + 1, cell);
        }
        
        

        return adjList;
    }

    //Calculate targets
    public void calcTargets(BoardCell startCell, int pathLength) {
        targets = new HashSet<>();
        findTargets(startCell, pathLength, new HashSet<>());
    }
    


    //  Getter for targets
    public Set<BoardCell> getTargets() {
        return targets;
    }

    
    //Gets the total number of rows in the board.
    public int getNumRows() {
        return numRows;
    }

    //Gets the total number of rows in the board.
    public int getNumColumns() {
        return numColumns;
    }

    //Returns the BoardCell at a given row and column.
    public BoardCell getCell(int row, int col) {
    	if (grid == null ) {
    		throw new RuntimeException("ERROR: Grid is null. Did you call initialize()?");
    	}
    	if (row < 0 || row >= numRows || col < 0 || col >= numColumns) {
            System.out.println("ERROR: Attempted to access invalid cell [" + row + "][" + col + "] (Out of bounds).");
            return null;
        }
    	if (grid[row][col] == null) {
            throw new RuntimeException("ERROR: BoardCell at [" + row + "][" + col + "] is null. Check `loadLayoutConfig()`.");
        }
    	
    	return grid[row][col];
    }

    // Existing method: Gets the Room using a character initial
    public Room getRoom(char initial) {
    	if (!roomMap.containsKey(initial)) {
            //System.out.println("ERROR: Room with initial '" + initial + "' not found in roomMap.");
            return null;
        }
        return roomMap.get(initial);
    }

    // New overloaded method: Gets the Room using a BoardCell
    public Room getRoom(BoardCell cell) {
        if (cell.isDoorway()) {
            int row = cell.getRow(), col = cell.getCol();
            switch (cell.getDoorDirection()) {
                case UP: row--; break;
                case DOWN: row++; break;
                case LEFT: col--; break;
                case RIGHT: col++; break;
                default: break;
            }
            return roomMap.get(grid[row][col].getInitial());
        }
        return roomMap.get(cell.getInitial());
    }
    
    //Returns the correct (hidden) solution to the game — the answer that players try to guess.
    public Solution getSolution() {
        return theAnswer;
    }

    //Returns the list of all players currently in the game.
    public ArrayList<Player> getPlayers() {
        return players;
    }

    //Returns the full deck of all Card objects (weapons, rooms, people), excluding the solution cards if they've been removed and dealt.
    public ArrayList<Card> getDeck() {
        return deck;
    }
    
    //Checks if a player's accusation matches the actual solution to the game.
    public boolean checkAccusation(Solution accusation) {
        boolean personMatches = accusation.getPerson().equals(theAnswer.getPerson());
        boolean weaponMatches = accusation.getWeapon().equals(theAnswer.getWeapon());
        boolean roomMatches = accusation.getRoom().equals(theAnswer.getRoom());

        return personMatches && weaponMatches && roomMatches;
    }
    
    //Processes a suggestion and checks whether any other player can disprove it.
    public Card handleSuggestion(Solution suggestion, Player suggestingPlayer) {
        int startIndex = players.indexOf(suggestingPlayer);
        int playerCount = players.size();

        for (int i = 1; i < playerCount; i++) {
            int currentIndex = (startIndex + i) % playerCount;
            Player currentPlayer = players.get(currentIndex);
            Card disprovingCard = currentPlayer.disproveSuggestion(suggestion);
            if (disprovingCard != null) {
                return disprovingCard;
            }
        }

        return null;
    }
    
    public void setSolution(Solution solution) {
        this.theAnswer = solution;
    }
    
    //Retrieves a specific card from the deck based on its name and type.
    public Card getCard(String name, CardType type) {
        for (Card c : deck) {
            if (c.getCardName().equals(name) && c.getType() == type) {
                return c;
            }
        }
        throw new IllegalArgumentException("Card not found: " + name + " (" + type + ")");
    }
    
    
    /**
     * Called automatically by Swing whenever the panel needs to be redrawn.
     * This method draws the board grid and all player tokens.
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawBoard(g);
        drawPlayers(g);
    }

    /**
     * Returns the human player from the list of all players.
     * Assumes there is only one HumanPlayer in the game.
     *
     */
    public Player getHumanPlayer() {
        for (Player p : players) {
            if (p instanceof HumanPlayer) return p;
        }
        return null;
    }
}
