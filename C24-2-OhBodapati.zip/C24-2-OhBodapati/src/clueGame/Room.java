package clueGame;

public class Room {
    private String name;
    private BoardCell centerCell;
    private BoardCell labelCell;
    
    public Room(String name) {
        this.name = name;
    }

    //Returns the name of the room.
    public String getName() {
        return name;
    }

    //Gets the center cell of the room.
    public BoardCell getCenterCell() {
        return centerCell;
    }

    //Sets the center cell of the room.
    public void setCenterCell(BoardCell centerCell) {
        this.centerCell = centerCell;
    }

    //Gets the label cell of the room.
    public BoardCell getLabelCell() {
        return labelCell;
    }

    //Sets the label cell of the room.
    public void setLabelCell(BoardCell labelCell) {
        this.labelCell = labelCell;
    }
}
