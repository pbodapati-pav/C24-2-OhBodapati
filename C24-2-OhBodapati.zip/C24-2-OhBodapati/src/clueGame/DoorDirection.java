package clueGame;

//representing possible door directions.
public enum DoorDirection {
	UP, DOWN, LEFT, RIGHT, NONE;
}
