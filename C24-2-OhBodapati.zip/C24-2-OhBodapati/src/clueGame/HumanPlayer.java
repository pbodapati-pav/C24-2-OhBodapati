package clueGame;

import java.awt.Color;


/**
 * Represents a human-controlled player in the game.
 * Inherits from the abstract Player class.
 */
public class HumanPlayer extends Player{
	public HumanPlayer(String name, Color color, int row, int column) {
		super(name,color,row,column);
	}

}
