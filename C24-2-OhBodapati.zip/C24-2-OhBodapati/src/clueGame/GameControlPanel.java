package clueGame;

import java.awt.*;
import javax.swing.*;


/**
 * A JPanel for displaying game status, including turn info, roll, guess, and results.
 */
public class GameControlPanel extends JPanel {
    private JTextField whoseTurnField;
    private JTextField rollField;
    private JTextField guessField;
    private JTextField guessResultField;

    public GameControlPanel() {
        setLayout(new GridLayout(2, 1));

        // Top panel
        JPanel topPanel = new JPanel(new GridLayout(1, 4));
        JPanel turnPanel = new JPanel(new GridLayout(2, 1));
        JLabel turnLabel = new JLabel("Whose turn?");
        whoseTurnField = new JTextField(10);
        whoseTurnField.setEditable(false);
        turnPanel.add(turnLabel);
        turnPanel.add(whoseTurnField);
        topPanel.add(turnPanel);

        JPanel rollPanel = new JPanel(new GridLayout(2, 1));
        JLabel rollLabel = new JLabel("Roll:");
        rollField = new JTextField(5);
        rollField.setEditable(false);
        rollPanel.add(rollLabel);
        rollPanel.add(rollField);
        topPanel.add(rollPanel);

        JButton accusationButton = new JButton("Make Accusation");
        JButton nextButton = new JButton("NEXT!");
        topPanel.add(accusationButton);
        topPanel.add(nextButton);

        // Bottom panel
        JPanel bottomPanel = new JPanel(new GridLayout(1, 2));
        JPanel guessPanel = new JPanel(new BorderLayout());
        guessPanel.setBorder(BorderFactory.createTitledBorder("Guess"));
        guessField = new JTextField();
        guessField.setEditable(false);
        guessPanel.add(guessField);
        bottomPanel.add(guessPanel);

        JPanel resultPanel = new JPanel(new BorderLayout());
        resultPanel.setBorder(BorderFactory.createTitledBorder("Guess Result"));
        guessResultField = new JTextField();
        guessResultField.setEditable(false);
        resultPanel.add(guessResultField);
        bottomPanel.add(resultPanel);

        add(topPanel);
        add(bottomPanel);
    }
    
    //Updates the current player's name and background color.
    public void setTurn(String name, Color color) {
        whoseTurnField.setText(name);
        whoseTurnField.setBackground(color);
    }
    
    //Updates the roll display with the given number.
    public void setRoll(int roll) {
        rollField.setText(String.valueOf(roll));
    }
    //Updates the guess text field with the provided guess.
    public void setGuess(String guess) {
        guessField.setText(guess);
    }
    
    //Displays the result of the guess (e.g., refuted or not).
    public void setGuessResult(String result) {
        guessResultField.setText(result);
    }
    
    //Test method to visually verify the layout and behavior of GameControlPanel.
    public static void main(String[] args) {
        GameControlPanel panel = new GameControlPanel();
        JFrame frame = new JFrame();
        frame.setContentPane(panel);
        frame.setSize(750, 180);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        // Sample test data
        panel.setTurn("Col. Mustard", Color.YELLOW);
        panel.setRoll(5);
        panel.setGuess("I have no guess!");
        panel.setGuessResult("So you have nothing?");
    }
}
