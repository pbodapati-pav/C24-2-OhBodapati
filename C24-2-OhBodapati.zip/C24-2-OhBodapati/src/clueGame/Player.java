package clueGame;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public abstract class Player {
	private String name;
	private Color color;
	private int row, column;
	private ArrayList<Card> hand;
	private Set<Card> seen = new HashSet<>();
	
	public Player(String name, Color color, int row, int column) {
		this.name = name;
		this.color = color;
		this.row = row;
		this.column = column;
		this.hand = new ArrayList<>();
	}
	
	public Set<Card> getSeen() {
	    return seen;
	}

	
	// Adds a card to the player's hand.
	public void updateHand(Card card) {
		hand.add(card);
	}
	
	// Returns the list of cards in the player's hand.
	public ArrayList<Card> getHand() {
		return hand;
	}
	
	// Returns the player's color.
	public Color getColor() {
		return color;
	}
	
	// Returns the player's name.
	public String getName() {
        return name;
    }
	
	// Returns the player's current row position on the board.
    public int getRow() {
        return row;
    }
    
    // Returns the player's current column position on the board.
    public int getColumn() {
        return column;
    }
    
    // Method to disprove a suggestion.
    public Card disproveSuggestion(Solution suggestion) {
        List<Card> matchingCards = new ArrayList<>();
        for (Card card : hand) {
            if (card.equals(suggestion.getPerson()) ||
                card.equals(suggestion.getRoom()) ||
                card.equals(suggestion.getWeapon())) {
                matchingCards.add(card);
            }
        }

        if (matchingCards.isEmpty()) {
            return null;
        } else if (matchingCards.size() == 1) {
            return matchingCards.get(0);
        } else {
            Collections.shuffle(matchingCards, new Random());
            return matchingCards.get(0);
        }
    }
    
    /**
     * Draws the player as a colored circle (token) on the board.
     *
     */
    public void draw(Graphics g, int cellWidth, int cellHeight) {
    	// Convert the player's row and column to pixel coordinates
        int x = column * cellWidth;
        int y = row * cellHeight;
        
        // Margin around the token so it's not touching the cell edges
        int margin = Math.min(cellWidth, cellHeight) / 10;
        // Diameter of the token, slightly smaller than the cell size
        int diameter = Math.min(cellWidth, cellHeight) - 2 * margin;
        
        // Fill the token with the player's color
        g.setColor(color);
        g.fillOval(x + margin, y + margin, diameter, diameter);
        
        // Draw a black outline around the token
        g.setColor(Color.BLACK);
        g.drawOval(x + margin, y + margin, diameter, diameter);
    }

}
