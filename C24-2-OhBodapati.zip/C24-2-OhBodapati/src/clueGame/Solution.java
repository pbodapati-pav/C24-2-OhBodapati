package clueGame;

public class Solution {
	private Card person;
    private Card room;
    private Card weapon;

    public Solution(Card person, Card room, Card weapon) {
        this.person = person;
        this.room = room;
        this.weapon = weapon;
    }
    
    // Returns the person card in the solution.
    public Card getPerson() {
        return person;
    }
    
    // Returns the room card in the solution.
    public Card getRoom() {
        return room;
    }
    
    // Returns the weapon card in the solution.
    public Card getWeapon() {
        return weapon;
    }
    
    // Checks whether the given person, room, and weapon match the solution.
    public boolean matches(Card p, Card r, Card w) {
        return person.equals(p) && room.equals(r) && weapon.equals(w);
    }
    
    // Returns a string representation of the solution.
    @Override
    public String toString() {
        return "Solution: " + person + ", " + room + ", " + weapon;
    }

}
