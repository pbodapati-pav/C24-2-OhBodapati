package clueGame;

/**
 * Represents the type of a card in the game.
 * A card can be a PERSON, ROOM, or WEAPON.
 */
public enum CardType {
	PERSON, ROOM, WEAPON;
}
