package clueGame;

import javax.swing.JFrame;
import java.awt.BorderLayout;

public class ClueGame extends JFrame {

	public ClueGame() {
        setTitle("Clue Game - CSCI306");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize and configure the game board
        Board board = Board.getInstance();
        board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
        board.initialize();
        add(board, BorderLayout.CENTER);

        // Control panel at the bottom
        GameControlPanel controlPanel = new GameControlPanel();
        add(controlPanel, BorderLayout.SOUTH);

        // Known cards panel on the right
        KnownCardsPanel knownCardsPanel = new KnownCardsPanel();
        add(knownCardsPanel, BorderLayout.EAST);

        // Pass human player's data to the known cards panel
        Player human = board.getHumanPlayer();
        if (human != null) {
            knownCardsPanel.setPlayer(human);
        }

        setVisible(true);
    }

    public static void main(String[] args) {
        new ClueGame();
    }
}
