package tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import clueGame.*;

import java.util.*;

public class ComputerAITest {

    private ComputerPlayer computer;
    private Board board;
    private Card seenCard = new Card("SeenCard", CardType.WEAPON);
    
    //because the AI state resets every time
    @BeforeEach
    public void setup() {
        board = Board.getInstance();
        board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
        board.initialize();

        computer = new ComputerPlayer("TestComp", java.awt.Color.gray, 5, 3);
        computer.getSeen().clear();
    }

    @Test
    public void testOnlyOneUnseenWeapon() {
        Card knife = board.getCard("Knife", CardType.WEAPON);

        // Mark all weapons as seen EXCEPT Knife
        computer.getSeen().add(board.getCard("Candlestick", CardType.WEAPON));
        computer.getSeen().add(board.getCard("Revolver", CardType.WEAPON));
        computer.getSeen().add(board.getCard("Rope", CardType.WEAPON));
        computer.getSeen().add(board.getCard("Wrench", CardType.WEAPON));
        computer.getSeen().add(board.getCard("Lead Pipe", CardType.WEAPON));

        Solution suggestion = computer.createSuggestion();

        assertEquals(knife, suggestion.getWeapon());
    }


    @Test
    public void testOnlyOneUnseenPerson() {
        Card scarlet = board.getCard("Miss Scarlet", CardType.PERSON);

        // Add all other people to seen
        computer.getSeen().add(board.getCard("Professor Plum", CardType.PERSON));
        computer.getSeen().add(board.getCard("Mrs. Peacock", CardType.PERSON));
        computer.getSeen().add(board.getCard("Colonel Mustard", CardType.PERSON));
        computer.getSeen().add(board.getCard("Mrs. White", CardType.PERSON));
        computer.getSeen().add(board.getCard("Mr. Green", CardType.PERSON));

        // Debug print
        System.out.println("Unseen people:");
        for (Card c : board.getDeck()) {
            if (c.getType() == CardType.PERSON && !computer.getSeen().contains(c)) {
                System.out.println("- " + c.getCardName());
            }
        }

        Solution suggestion = computer.createSuggestion();

        assertEquals(scarlet, suggestion.getPerson());
    }



    @Test
    public void testMultipleOptionsRandomlyChosen() {
        Set<Card> personResults = new HashSet<>();
        Set<Card> weaponResults = new HashSet<>();

        for (int i = 0; i < 30; i++) {
            computer.getSeen().clear();
            computer.getSeen().add(seenCard); // unrelated seen card
            Solution suggestion = computer.createSuggestion();
            personResults.add(suggestion.getPerson());
            weaponResults.add(suggestion.getWeapon());
        }

        assertTrue(personResults.size() > 1);
        assertTrue(weaponResults.size() > 1);
    }

    @Test
    public void testNoRoomChoosesRandomly() {
        Set<BoardCell> targets = Set.of(
            new BoardCell(5, 4, 'W'),
            new BoardCell(5, 5, 'W'),
            new BoardCell(5, 6, 'W')
        );

        Set<BoardCell> chosenTargets = new HashSet<>();
        for (int i = 0; i < 20; i++) {
            chosenTargets.add(computer.selectTargets(targets));
        }

        assertTrue(chosenTargets.size() > 1);
    }

    @Test
    public void testRoomChosenIfUnvisited() {
        Room library = board.getRoom('L');
        BoardCell roomCell = library.getCenterCell();

        Set<BoardCell> targets = Set.of(
            roomCell,
            new BoardCell(5, 4, 'W')
        );

        computer.setLastRoomVisited("Kitchen");
        BoardCell result = computer.selectTargets(targets);
        assertEquals("Library", board.getRoom(result).getName());
    }

    @Test
    public void testRoomSeenSelectsRandomly() {
        BoardCell roomCell = new BoardCell(3, 3, 'K');

        Set<BoardCell> targets = Set.of(
            roomCell,
            new BoardCell(5, 4, 'W')
        );

        computer.setLastRoomVisited("Kitchen");

        Set<BoardCell> chosenTargets = new HashSet<>();
        for (int i = 0; i < 20; i++) {
            chosenTargets.add(computer.selectTargets(targets));
        }

        assertTrue(chosenTargets.contains(roomCell));
        assertTrue(chosenTargets.size() > 1);
    }
}
