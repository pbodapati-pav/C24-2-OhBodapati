package tests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import clueGame.Board;
import clueGame.BoardCell;
import clueGame.DoorDirection;
import clueGame.Room;

public class FileInitTests {
	public static final int LEGEND_SIZE = 11;  // Adjust this for your board
    public static final int NUM_ROWS = 25;  // Adjust based on ClueLayout.csv
    public static final int NUM_COLUMNS = 23;  // Adjust based on ClueLayout.csv
    
    private static Board board;
    
    @BeforeAll
    public static void setUp() {
        board = Board.getInstance();
        board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
        board.initialize();
        System.out.println("Board initialized: " + board.getNumRows() + "x" + board.getNumColumns());
    }
    
    @Test
    public void testRoomLabels() {
        assertEquals("Library", board.getRoom('L').getName());
        assertEquals("Kitchen", board.getRoom('K').getName());
        assertEquals("Conservatory", board.getRoom('C').getName());
        assertEquals("Ballroom", board.getRoom('B').getName());
        assertEquals("Study", board.getRoom('S').getName());
    }
    
    
    @Test
    public void testBoardDimensions() {
        assertEquals(NUM_ROWS, board.getNumRows());
        assertEquals(NUM_COLUMNS, board.getNumColumns());
    }
    
    @Test
    public void testDoorDirections() {
        BoardCell leftDoor = board.getCell(11, 6); //Change original(8,7) 
        assertTrue(leftDoor.isDoorway());
        assertEquals(DoorDirection.LEFT, leftDoor.getDoorDirection());

        BoardCell upDoor = board.getCell(5, 5); //Change original(7, 5)
        assertTrue(upDoor.isDoorway());
        assertEquals(DoorDirection.UP, upDoor.getDoorDirection());

        BoardCell rightDoor = board.getCell(9, 7); //Change original(4, 8)
        assertTrue(rightDoor.isDoorway());
        assertEquals(DoorDirection.RIGHT, rightDoor.getDoorDirection());

        BoardCell downDoor = board.getCell(16, 8); //Change original(16, 9)
        assertTrue(downDoor.isDoorway());
        assertEquals(DoorDirection.DOWN, downDoor.getDoorDirection());

        // Check a cell that is NOT a doorway
        BoardCell notDoorway = board.getCell(12, 14);
        assertFalse(notDoorway.isDoorway());
    }
    
    @Test
    public void testNumberOfDoorways() {
        int numDoors = 0;
        for (int row = 0; row < board.getNumRows(); row++) {
            for (int col = 0; col < board.getNumColumns(); col++) {
                BoardCell cell = board.getCell(row, col);
                if (cell.isDoorway()) numDoors++;
            }
        }
        Assert.assertEquals(20, numDoors);  // Adjust this to match your board's expected door count (Suppose to be 20 not 18)
    }
    
    @Test
    public void testRoomCentersAndLabels() {
        // Check if the Ballroom has a center cell
        BoardCell ballroomCenter = board.getCell(1, 8); //Change original(20, 11)
        Room ballroom = board.getRoom(ballroomCenter);
        assertTrue(ballroomCenter.isRoomCenter());
        assertEquals(ballroom.getCenterCell(), ballroomCenter);

        // Check if the Lounge has a label cell
        BoardCell loungeLabel = board.getCell(18, 10); //Change original(2, 19)
        Room lounge = board.getRoom(loungeLabel);
        assertTrue(loungeLabel.isLabel());
        assertEquals(lounge.getLabelCell(), loungeLabel);
    }

}