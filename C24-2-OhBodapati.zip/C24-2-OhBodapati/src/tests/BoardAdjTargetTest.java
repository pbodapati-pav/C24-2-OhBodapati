package tests;

import static org.junit.Assert.*;
import java.util.Set;
import org.junit.Before;
import org.junit.Test;
import clueGame.Board;
import clueGame.BoardCell;

public class BoardAdjTargetTest {

    private static Board board;

    @Before
    public void setUp() {
        board = Board.getInstance();
        board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
        board.initialize();
    }

    @Test
    public void testWalkwaysOnlyAdjacency() {
        BoardCell cell = board.getCell(5, 5);
        Set<BoardCell> adjCells = board.getAdjList(5, 5);
        assertTrue(adjCells.contains(board.getCell(5, 4)));
        assertTrue(adjCells.contains(board.getCell(5, 6)));
        assertTrue(adjCells.contains(board.getCell(6, 5)));
        
    }

    @Test
    public void testInsideRoomAdjacency() {
        BoardCell cell = board.getCell(2, 2);
        Set<BoardCell> adjCells = board.getAdjList(2, 2);
        assertTrue(adjCells.isEmpty());
    }

    @Test
    public void testEdgeOfBoardAdjacency() {
        BoardCell cell = board.getCell(0, 5);
        Set<BoardCell> adjCells = board.getAdjList(0, 5);
        assertFalse(adjCells.contains(board.getCell(1, 5)));
    }

    @Test
    public void testBesideRoomNotDoorwayAdjacency() {
        BoardCell cell = board.getCell(4, 0);
        Set<BoardCell> adjCells = board.getAdjList(4, 0);
        assertFalse(adjCells.contains(board.getCell(4, 1)));
    }

    @Test
    public void testDoorwayAdjacency() {
        BoardCell cell = board.getCell(7, 12);
        Set<BoardCell> adjCells = board.getAdjList(7, 12);
        assertTrue(adjCells.contains(board.getCell(6, 12)));
    }

    @Test
    public void testSecretPassageAdjacency() {
        BoardCell cell = board.getCell(4, 3);
        Set<BoardCell> adjCells = board.getAdjList(4, 3);
        assertTrue(adjCells.contains(board.getCell(17, 2)));
    }

    @Test
    public void testWalkwayTargets() {
        BoardCell startCell = board.getCell(6, 6);
        board.calcTargets(startCell, 2);
        Set<BoardCell> targets = board.getTargets();
        assertTrue(targets.contains(board.getCell(6, 4)));
        assertTrue(targets.contains(board.getCell(6, 8)));
    }

    @Test
    public void testEnteringRoomTargets() {
        BoardCell startCell = board.getCell(8, 7);
        board.calcTargets(startCell, 1);
        Set<BoardCell> targets = board.getTargets();
        System.out.println("Start Cell: (8,7) = " + board.getCell(8, 7));
        System.out.println("Adjacents to (8,7):");
        for (BoardCell c : board.getAdjList(8, 7)) {
            System.out.println(" -> (" + c.getRow() + "," + c.getCol() + ") isDoorway=" + c.isDoorway() + " isRoomCenter=" + c.isRoomCenter());
        }

        assertTrue(targets.contains(board.getCell(8, 6)));
        assertTrue(targets.contains(board.getCell(7, 7)));
        
    }

    @Test
    public void testLeavingRoomNoSecretPassage() {
        BoardCell startCell = board.getCell(11, 3);
        board.calcTargets(startCell, 1);
        Set<BoardCell> targets = board.getTargets();
        assertTrue(targets.contains(board.getCell(11, 2)));
    }

    @Test
    public void testLeavingRoomWithSecretPassage() {
        BoardCell startCell = board.getCell(4, 3);
        board.calcTargets(startCell, 1);
        Set<BoardCell> targets = board.getTargets();
        assertTrue(targets.contains(board.getCell(17, 2)));
    }

    @Test
    public void testBlockedTargets() {
        board.getCell(6, 5).setOccupied(true);
        BoardCell startCell = board.getCell(6, 6);
        board.calcTargets(startCell, 2);
        Set<BoardCell> targets = board.getTargets();
        assertFalse(targets.contains(board.getCell(6, 4)));
    }
}
