package tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import clueGame.*;
import java.util.*;

public class GameSolutionTest {

    private static Board board;
    private static Player testPlayer;
    private static Player altPlayer;
    private static Solution solution;

    @BeforeAll
    public static void setUp() {
        board = Board.getInstance();
        board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
        board.initialize();
        testPlayer = board.getPlayers().get(0);
        altPlayer = board.getPlayers().get(1);
        solution = new Solution(
            new Card("Miss Scarlet", CardType.PERSON),
            new Card("Kitchen", CardType.ROOM),
            new Card("Wrench", CardType.WEAPON)
        );
        board.setSolution(solution);
        board.clearPlayerHands(); 
    }

    // checkAccusation() tests 

    @Test
    public void testCorrect() {
        assertTrue(board.checkAccusation(solution));
    }

    @Test
    public void testWrongPerson() {
        Solution wrong = new Solution(new Card("Colonel Mustard", CardType.PERSON), solution.getRoom(), solution.getWeapon());
        assertFalse(board.checkAccusation(wrong));
    }

    @Test
    public void testWrongRoom() {
        Solution wrong = new Solution(solution.getPerson(), new Card("Library", CardType.ROOM), solution.getWeapon());
        assertFalse(board.checkAccusation(wrong));
    }

    @Test
    public void testWrongWeapon() {
        Solution wrong = new Solution(solution.getPerson(), solution.getRoom(), new Card("Rope", CardType.WEAPON));
        assertFalse(board.checkAccusation(wrong));
    }

    //disproveSuggestion() tests 

    @Test
    public void testOneMatch() {
        Card c1 = new Card("Knife", CardType.WEAPON);
        testPlayer.getHand().clear();
        testPlayer.updateHand(c1);

        Solution suggestion = new Solution(new Card("Unused", CardType.PERSON), new Card("Unused", CardType.ROOM), c1);
        assertEquals(c1, testPlayer.disproveSuggestion(suggestion));
    }

    @Test
    public void testMultipleMatches() {
        Card p = new Card("Mr. Green", CardType.PERSON);
        Card w = new Card("Revolver", CardType.WEAPON);
        testPlayer.getHand().clear();
        testPlayer.updateHand(p);
        testPlayer.updateHand(w);

        Solution suggestion = new Solution(p, new Card("Unused", CardType.ROOM), w);
        // Run multiple times to verify both options appear
        Set<Card> results = new HashSet<>();
        for (int i = 0; i < 20; i++) {
            results.add(testPlayer.disproveSuggestion(suggestion));
        }
        assertTrue(results.contains(p));
        assertTrue(results.contains(w));
    }

    @Test
    public void testNoMatch() {
        testPlayer.getHand().clear();
        testPlayer.updateHand(new Card("Library", CardType.ROOM));
        Solution suggestion = new Solution(new Card("Unused", CardType.PERSON), new Card("Unused", CardType.ROOM), new Card("Unused", CardType.WEAPON));
        assertNull(testPlayer.disproveSuggestion(suggestion));
    }

    //handleSuggestion() tests 

    @Test
    public void testNoOneCanDisprove() {
        Solution suggestion = new Solution(new Card("Unused Person", CardType.PERSON), new Card("Unused Room", CardType.ROOM), new Card("Unused Weapon", CardType.WEAPON));
        assertNull(board.handleSuggestion(suggestion, testPlayer));
    }

    @Test
    public void testOnlySuggesterCanDisprove() {
        Card match = new Card("Wrench", CardType.WEAPON);
        testPlayer.getHand().clear();
        testPlayer.updateHand(match);
        Solution suggestion = new Solution(new Card("Unused", CardType.PERSON), new Card("Unused", CardType.ROOM), match);
        assertNull(board.handleSuggestion(suggestion, testPlayer));
    }

    @Test
    public void testHumanCanDisprove() {
        Card match = new Card("Rope", CardType.WEAPON);
        altPlayer.getHand().clear();
        altPlayer.updateHand(match);
        Solution suggestion = new Solution(new Card("Unused", CardType.PERSON), new Card("Unused", CardType.ROOM), match);
        assertEquals(match, board.handleSuggestion(suggestion, testPlayer));
    }

    @Test
    public void testMultipleCanDisprove() {
        Player p1 = board.getPlayers().get(1);
        Player p2 = board.getPlayers().get(2);
        Card match1 = new Card("Knife", CardType.WEAPON);
        Card match2 = new Card("Candlestick", CardType.WEAPON);
        p1.getHand().clear();
        p2.getHand().clear();
        p1.updateHand(match1);
        p2.updateHand(match2);
        Solution suggestion = new Solution(new Card("Unused", CardType.PERSON), new Card("Unused", CardType.ROOM), match1);
        assertEquals(match1, board.handleSuggestion(suggestion, testPlayer));
    }
}