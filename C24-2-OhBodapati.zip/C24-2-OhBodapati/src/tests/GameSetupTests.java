package tests;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import clueGame.Board;
import clueGame.Player;
import clueGame.Card;
import clueGame.CardType;

public class GameSetupTests {

	private static Board board;

	@BeforeAll
	public static void setUp() {
		board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
		board.initialize();
	}

	@Test
	public void testLoadPeople() {
		ArrayList<Player> players = board.getPlayers();
		assertEquals(6, players.size());
		Player scarlet = players.get(0);
		assertEquals("Miss Scarlet", scarlet.getName());
		assertEquals(5, scarlet.getRow());
		assertEquals(3, scarlet.getColumn());
		assertEquals(java.awt.Color.RED, scarlet.getColor());
	}

	@Test
	public void testLoadWeapons() {
		List<Card> deck = board.getDeck();
		long weaponCount = deck.stream()
				.filter(c -> c.getType() == CardType.WEAPON)
				.count();
		assertEquals(6, (int) weaponCount);
	}

	@Test
	public void testLoadRoomsIntoDeck() {
		List<Card> deck = board.getDeck();
		long roomCount = deck.stream()
				.filter(c -> c.getType() == CardType.ROOM)
				.count();
		assertEquals(9, (int) roomCount);
	}

	@Test
	public void testLoadPeopleIntoDeck() {
		List<Card> deck = board.getDeck();
		long personCount = deck.stream()
				.filter(c -> c.getType() == CardType.PERSON)
				.count();
		assertEquals(6, (int) personCount);
	}

	@Test
	public void testDealAllCards() {
		List<Card> allCards = new ArrayList<>();
		for (Player p : board.getPlayers()) {
			allCards.addAll(p.getHand());
		}

		
		int expectedCount = board.getDeck().size() - 3;
		assertEquals(expectedCount, allCards.size());

		Set<Card> uniqueCards = new HashSet<>(allCards);
		assertEquals(allCards.size(), uniqueCards.size());

		int min = Integer.MAX_VALUE;
		int max = Integer.MIN_VALUE;
		for (Player p : board.getPlayers()) {
			int size = p.getHand().size();
			min = Math.min(min, size);
			max = Math.max(max, size);
		}
		assertTrue(max - min <= 1);
	}
}

